/*
     Author: Bryan Rolle
     Purpose: SDC260 Project
     Date: 9/26/2026
*/


// Forms Javascript Page
function validateField(field) {
    const value = field.value.trim();
    let error = "";

    if (field.required && !value) {
        error = "This field is required.";
    } else if (field.type === "email" && value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        error = "Enter a valid email address.";
    } else if (field.id === "zip-code" && value && !/^\d{5}(-\d{4})?$/.test(value)) {
        error = "Enter a 5-digit ZIP code or ZIP+4.";
    } else if (field.id === "phone" && value && !/^\+?\d[\d\s().-]*$/.test(value)) {
        error = "Enter a valid phone number.";
    } else if (field.id === "phone" && value && value.replace(/\D/g, "").length < 10) {
        error = "Enter a phone number with at least 10 digits.";
    } else if (field.id === "card-number" && value && !validCardNumber(value)) {
        error = "Enter a valid credit card number.";
    } else if (field.id === "expiration-date" && value) {
        const [year, month] = value.split("-").map(Number);
        const today = new Date();
        if (!year || !month || month < 1 || month > 12 ||
            year < today.getFullYear() ||
            (year === today.getFullYear() && month < today.getMonth() + 1)) {
            error = "Enter a future expiration month.";
        }
    } else if (field.id === "security-code" && value && !/^\d{3,4}$/.test(value)) {
        error = "Enter a 3 or 4 digit security code.";
    }

    field.setCustomValidity(error);
    field.setAttribute("aria-invalid", error ? "true" : "false");
    return !error;
}

function validCardNumber(value) {
    const digits = value.replace(/[ -]/g, "");
    if (!/^\d{13,19}$/.test(digits) || /[^\d -]/.test(value)) return false;

    let sum = 0;
    let doubleDigit = false;

    for (let i = digits.length - 1; i >= 0; i--) {
        let digit = Number(digits[i]);
        if (doubleDigit) {
            digit *= 2;
            if (digit > 9) digit -= 9;
        }
        sum += digit;
        doubleDigit = !doubleDigit;
    }

    return sum % 10 === 0;
}

function validateForm(form) {
    let firstInvalid = null;

    for (const field of form.querySelectorAll("input, textarea")) {
        if (!validateField(field) && !firstInvalid) firstInvalid = field;
    }

    if (firstInvalid) {
        firstInvalid.focus();
        firstInvalid.reportValidity();
        return false;
    }

    return true;
}

function attachValidation(form) {
    form.addEventListener("input", event => {
        if (event.target.matches("input, textarea")) validateField(event.target);
    });

    form.addEventListener("change", event => {
        if (event.target.matches("input, textarea")) validateField(event.target);
    });
}

const contactForm = document.querySelector("#contact-form");

if (contactForm) {
    attachValidation(contactForm);

    contactForm.addEventListener("submit", event => {
        event.preventDefault();
        if (!validateForm(contactForm)) return;

        document.querySelector("#form-status").textContent =
            "Form completed. Message delivery has not been set up yet.";
    });
}

const checkoutForm = document.querySelector("#checkout-form");

if (checkoutForm) {
    attachValidation(checkoutForm);

    const cartItems = readCart();
    const subtotal = cartItems.reduce(
        (sum, index) => sum + products[index].priceCents, 0
    );

    const couponInput = document.querySelector("#coupon-code");
    const couponStatus = document.querySelector("#coupon-status");

    const coupons = {
        GAMER10: { percent: 10, category: "all" },
        GAMES15: { percent: 15, category: "games" }
    };

    let discount = 0;
    let validCoupon = true;

    const list = document.querySelector("#cart-items");

    if (!cartItems.length) {
        const item = document.createElement("li");
        item.textContent = "Your cart is empty. Add products before checkout.";
        list.append(item);
    }

    for (const index of cartItems) {
        const item = document.createElement("li");
        item.textContent =
            `${products[index].name} — ${formatPrice(products[index].priceCents)}`;
        list.append(item);
    }

    function updateTotals() {
        document.querySelector("#subtotal").textContent = formatPrice(subtotal);
        document.querySelector("#discount").textContent = `-${formatPrice(discount)}`;
        document.querySelector("#total").textContent = formatPrice(subtotal - discount);
    }

    function applyCoupon() {
        const code = couponInput.value.trim().toUpperCase();
        const coupon = coupons[code];

        discount = 0;
        validCoupon = true;
        couponInput.setCustomValidity("");
        couponInput.setAttribute("aria-invalid", "false");

        if (!code) {
            couponStatus.textContent = "No coupon applied.";
        } else if (!coupon) {
            validCoupon = false;
            couponInput.setCustomValidity("Coupon code not found.");
            couponInput.setAttribute("aria-invalid", "true");
            couponStatus.textContent = "Coupon code not found.";
        } else {
            const eligible = cartItems.reduce((sum, index) => {
                const product = products[index];

                return sum + (
                    coupon.category === "all" ||
                    product.category === coupon.category
                        ? product.priceCents
                        : 0
                );
            }, 0);

            if (!eligible) {
                validCoupon = false;
                couponInput.setCustomValidity(
                    "This coupon does not apply to the products in your cart."
                );
                couponInput.setAttribute("aria-invalid", "true");
                couponStatus.textContent =
                    "This coupon does not apply to the products in your cart.";
            } else {
                discount = Math.round(eligible * coupon.percent / 100);
                couponStatus.textContent =
                    `${code} applied: ${coupon.percent}% off ${
                        coupon.category === "all" ? "your order" : "games"
                    }.`;
            }
        }

        updateTotals();
        return validCoupon;
    }

    couponInput.addEventListener("input", () => {
        couponInput.setCustomValidity("");
        couponInput.setAttribute("aria-invalid", "false");
        validCoupon = true;
        discount = 0;
        couponStatus.textContent = "Apply the coupon to update your total.";
        updateTotals();
    });

    document.querySelector("#apply-coupon").addEventListener("click", applyCoupon);
    updateTotals();

    checkoutForm.addEventListener("submit", event => {
        event.preventDefault();

        const status = document.querySelector("#checkout-status");

        if (!cartItems.length) {
            status.textContent = "Add at least one product to your cart first.";
            return;
        }

        if (!applyCoupon()) {
            couponInput.focus();
            couponInput.reportValidity();
            return;
        }

        if (!validateForm(checkoutForm)) return;

        status.textContent =
            "Fields are valid. Payment processing is not available yet; no card details were submitted.";
    });
}