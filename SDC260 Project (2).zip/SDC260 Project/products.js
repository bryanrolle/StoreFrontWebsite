
/*
     Author: Bryan Rolle
     Purpose: SDC260 Project
     Date: 9/26/2026
*/

// Products Javascript Page

const products = [
    {
        name: "Star Wars Outlaws",
        image: "Pictures/Star Wars Outlaws.c9a243fc-a2dc-4816-8c81-a2c39adda241",
        description: "A Star Wars game that is open-world!",
        alt: "Description of Star Wars Outlaws",
        priceCents: 6999,
        category: "games",
    },
    {
        name: "God of War Ragnorok",
        image: "Pictures/God_of_War_Ragnarok.jpg",
        description: "A thrilling action-packed story game!",
        alt: "Description of God of War Ragnorok",
        priceCents: 6999,
        category: "games",
    },
    {
        name: "Horizon Zero Dawn",
        image: "Pictures/Horizon_Zero_Dawn.jpg",
        description: "A post world story game filled with action!",
        alt: "Description of Horizon Zero Dawn",
        priceCents: 6999,
        category: "games",
    },
    {
        name: "PS5",
        image: "Pictures/PS5.jfif",
        description: "Playstation 5!",
        alt: "Description of the PS5",
        priceCents: 49999,
        category: "consoles",
    },
    {
        name: "Xbox Series X",
        image: "Pictures/Xbox Series X.png",
        description: "Xbox Series X!",
        alt: "Description of Xbox Series X",
        priceCents: 44999,
        category: "consoles",
    },
    {
        name: "Nintendo Switch 2",
        image: "Pictures/Nintendo-Switch-2.jfif",
        description: "Nintendo Switch 2!",
        alt: "Description of Nintendo Switch 2",
        priceCents: 44999,
        category: "consoles",
    },
    {
        name: "HyperX Cloud 2",
        image: "Pictures/hyperx_cloud_ii_headset.webp",
        description: "HyperX Cloud 2 Headset!",
        alt: "Description of Hyper X Cloud 2",
        priceCents: 7999,
        category: "equipment",
    },
    {
        name: "HyperX Keyboard",
        image: "Pictures/hyperx_keyboard.webp",
        description: "HyperX Alloy Origins Core Keyboard!",
        alt: "Description of Hyper X Keyboard",
        priceCents: 8999,
        category: "equipment",
    },
    {
        name: "Logitech G502 Hero Mouse",
        image: "Pictures/G502_Hero_Mouse.jfif",
        description: "Logitech G502 Hero Mouse!",
        alt: "Description of Logitech G502 Hero Mouse",
        priceCents: 4999,
        category: "equipment",
    },
    {
        name: "Kratos Funko Pop",
        image: "Pictures/Kratos Funko Pop.png",
        description: "Kratos Funko Pop!",
        alt: "Description of Kratos Funko Pop",
        priceCents: 1499,
        category: "figurines",
    },
    {
        name: "Naruto Funko Pop",
        image: "Pictures/Naruto Funko Pop.png",
        description: "Naruto Funko Pop!",
        alt: "Description of Naruto Funko Pop",
        priceCents: 1499,
        category: "figurines",
    },
    {
        name: "Batman Funko Pop",
        image: "Pictures/Batman Funko Pop.png",
        description: "Batman Funko Pop!",
        alt: "Description of Batman Funko Pop",
        priceCents: 1499,
        category: "figurines",
    }
];

const CART_KEY = "gamer-cart-v1";
const formatPrice = cents => `$${(cents / 100).toFixed(2)}`;
let memoryCart = [];

function validCart(items) {
    return Array.isArray(items)
        ? items.filter(index =>
            Number.isInteger(index) &&
            index >= 0 &&
            index < products.length
        )
        : [];
}

function readCart() {
    const cartFromLink = new URLSearchParams(window.location.search).get("cart");

    if (cartFromLink !== null) {
        return validCart(cartFromLink.split(",").filter(Boolean).map(Number));
    }

    try {
        const cart = JSON.parse(localStorage.getItem(CART_KEY) || "[]");
        return validCart(cart);
    } catch {
        return memoryCart;
    }
}

function addToCart(index) {
    const cart = readCart();
    cart.push(index);
    memoryCart = cart;

    try {
        localStorage.setItem(CART_KEY, JSON.stringify(cart));
    } catch {
        // The checkout link still carries the cart if browser storage is unavailable.
    }

    return true;
}

const productGrid = document.querySelector("#products");

if (productGrid) {
    const category = productGrid.dataset.category || "all";
    const visibleProducts = category === "all"
        ? products
        : products.filter(product => product.category === category);

    for (const product of visibleProducts) {
        const index = products.indexOf(product);
        const card = document.createElement("section");
        const title = document.createElement("h3");
        const image = document.createElement("img");
        const description = document.createElement("p");
        const price = document.createElement("p");
        const addButton = document.createElement("button");

        title.textContent = product.name;
        image.src = product.image;
        image.alt = product.alt;
        image.width = 300;
        description.textContent = product.description;
        price.textContent = `${formatPrice(product.priceCents)} (demo price)`;

        addButton.type = "button";
        addButton.textContent = "Add to cart";
        addButton.addEventListener("click", () => {
            addToCart(index);
            addButton.textContent = "Added!";
            setTimeout(() => {
                addButton.textContent = "Add to cart";
            }, 1500);
        });

        card.append(title, image, description, price, addButton);
        productGrid.append(card);
    }

    const checkoutLink = document.createElement("p");
    const link = document.createElement("a");
    link.href = "checkout.html";
    link.textContent = "Go to checkout";

    link.addEventListener("click", () => {
        link.href = `checkout.html?cart=${readCart().join(",")}`;
    });

    checkoutLink.append(link);
    productGrid.before(checkoutLink);
}