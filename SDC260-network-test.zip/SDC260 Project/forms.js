/*
     Author: Bryan Rolle
     Purpose: SDC260 Project
     Date: 9/26/2026
*/


// Forms Javascript Page
function validateField(field) {
    const value = field.value.trim();
    let error = "";

    if (field.required && !value) {
        error = "This field is required.";
    } else if (field.type === "email" && value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        error = "Enter a valid email address.";
    } else if (field.id === "zip-code" && value && !/^\d{5}(-\d{4})?$/.test(value)) {
        error = "Enter a 5-digit ZIP code or ZIP+4.";
    } else if (field.id === "phone" && value && !/^\+?\d[\d\s().-]*$/.test(value)) {
        error = "Enter a valid phone number.";
    } else if (field.id === "phone" && value && value.replace(/\D/g, "").length < 10) {
        error = "Enter a phone number with at least 10 digits.";
    } else if (field.id === "card-number" && value && !validCardNumber(value)) {
        error = "Enter a valid credit card number.";
    } else if (field.id === "expiration-date" && value) {
        const [year, month] = value.split("-").map(Number);
        const today = new Date();
        if (!year || !month || month < 1 || month > 12 ||
            year < today.getFullYear() ||
            (year === today.getFullYear() && month < today.getMonth() + 1)) {
            error = "Enter a future expiration month.";
        }
    } else if (field.id === "security-code" && value && !/^\d{3,4}$/.test(value)) {
        error = "Enter a 3 or 4 digit security code.";
    }

    field.setCustomValidity(error);
    field.setAttribute("aria-invalid", error ? "true" : "false");
    return !error;
}

function validCardNumber(value) {
    const digits = value.replace(/[ -]/g, "");
    if (!/^\d{13,19}$/.test(digits) || /[^\d -]/.test(value) || /^(\d)\1+$/.test(digits)) return false;

    let sum = 0;
    let doubleDigit = false;

    for (let i = digits.length - 1; i >= 0; i--) {
        let digit = Number(digits[i]);
        if (doubleDigit) {
            digit *= 2;
            if (digit > 9) digit -= 9;
        }
        sum += digit;
        doubleDigit = !doubleDigit;
    }

    return sum % 10 === 0;
}

function validateForm(form) {
    let firstInvalid = null;

    for (const field of form.querySelectorAll("input, textarea")) {
        if (!validateField(field) && !firstInvalid) firstInvalid = field;
    }

    if (firstInvalid) {
        firstInvalid.focus();
        firstInvalid.reportValidity();
        return false;
    }

    return true;
}

function attachValidation(form) {
    form.addEventListener("input", event => {
        if (event.target.matches("input, textarea")) validateField(event.target);
    });

    form.addEventListener("change", event => {
        if (event.target.matches("input, textarea")) validateField(event.target);
    });
}

const contactForm = document.querySelector("#contact-form");

if (contactForm) {
    attachValidation(contactForm);

    contactForm.addEventListener("submit", event => {
        event.preventDefault();
        if (!validateForm(contactForm)) return;

        document.querySelector("#form-status").textContent =
            "Form completed. Message delivery has not been set up yet.";
    });
}

const checkoutForm = document.querySelector("#checkout-form");
if (checkoutForm) {
    attachValidation(checkoutForm);
    const couponInput = document.querySelector("#coupon-code");
    const couponStatus = document.querySelector("#coupon-status");
    const coupons = {
        GAMER10: { percent: 10, category: "all" },
        GAMES15: { percent: 15, category: "games" }
    };
    let discount = 0;
    let appliedCode = "";
    function updateTotals() {
        document.querySelector("#subtotal").textContent = formatPrice(cartSubtotal());
        document.querySelector("#discount").textContent = `-${formatPrice(discount)}`;
        document.querySelector("#total").textContent = formatPrice(cartSubtotal() - discount);
    }
    function applyCoupon() {
        const code = couponInput.value.trim().toUpperCase();
        const coupon = Object.hasOwn(coupons, code) ? coupons[code] : null;
        discount = 0;
        appliedCode = "";
        let error = "";
        if (!code) couponStatus.textContent = "No coupon applied.";
        else if (!coupon) error = "Coupon code not found.";
        else {
            const eligible = readCart().reduce((sum, i) => sum +
                (coupon.category === "all" || products[i].category === coupon.category ? products[i].priceCents : 0), 0);
            if (!eligible) error = "This coupon does not apply to the products in your cart.";
            else {
                discount = Math.round(eligible * coupon.percent / 100);
                appliedCode = code;
                couponStatus.textContent = `${code}: ${coupon.percent}% off ${coupon.category === "all" ? "the order" : "games"}.`;
            }
        }
        if (error) couponStatus.textContent = error;
        couponInput.setCustomValidity(error);
        couponInput.setAttribute("aria-invalid", error ? "true" : "false");
        updateTotals();
        return !error;
    }
    couponInput.addEventListener("input", () => {
        discount = 0; appliedCode = "";
        couponInput.setCustomValidity("");
        couponInput.setAttribute("aria-invalid", "false");
        couponStatus.textContent = "Click Apply Coupon to update the total.";
        updateTotals();
    });
    document.querySelector("#apply-coupon").addEventListener("click", applyCoupon);
    document.addEventListener("cart-changed", () => {
        if (appliedCode) applyCoupon();
        else { discount = 0; updateTotals(); }
    });
    function showConfirmation(order) {
        const confirmation = document.querySelector("#order-confirmation");
        confirmation.replaceChildren();
        const heading = document.createElement("h2"); heading.textContent = "Order Confirmation";
        const number = document.createElement("p"); number.textContent = `Demo order ${order.id}`;
        const list = document.createElement("ul");
        for (const item of order.items) {
            const row = document.createElement("li");
            row.textContent = `${item.name} × ${item.quantity} — ${formatPrice(item.priceCents * item.quantity)}`;
            list.append(row);
        }
        const total = document.createElement("p");
        total.textContent = `Subtotal: ${formatPrice(order.subtotal)} | Discount: ${formatPrice(order.discount)} | Total: ${formatPrice(order.total)}`;
        const note = document.createElement("p"); note.textContent = "Demo order completed. No payment was charged.";
        confirmation.append(heading, number, list, total, note);
        confirmation.hidden = false;
    }
    updateTotals();
    if (!readCart().length && storeState.lastOrder) showConfirmation(storeState.lastOrder);
    checkoutForm.addEventListener("submit", event => {
        event.preventDefault();
        const status = document.querySelector("#checkout-status");
        if (!readCart().length) { status.textContent = "Add a product to your cart first."; return; }
        if (!validateForm(checkoutForm)) return;
        if (!applyCoupon()) { couponInput.focus(); couponInput.reportValidity(); return; }
        const order = completeOrder(discount, appliedCode);
        if (!order) { status.textContent = "Order could not be saved. Please allow browser storage."; return; }
        checkoutForm.reset();
        discount = 0; appliedCode = "";
        updateTotals(); couponStatus.textContent = "";
        status.textContent = "Demo order completed. Your cart is now empty.";
        showConfirmation(order);
    });
}
