
/*
     Author: Bryan Rolle
     Purpose: SDC260 Project
     Date: 9/26/2026
*/

// Products Javascript Page

const products = [
    {
        name: "Star Wars Outlaws",
        image: "Pictures/Star Wars Outlaws.c9a243fc-a2dc-4816-8c81-a2c39adda241",
        description: "A Star Wars game that is open-world!",
        alt: "Description of Star Wars Outlaws",
        priceCents: 6999,
        stock: 10, // Edit the starting inventory here.
        category: "games",
    },
    {
        name: "God of War Ragnorok",
        image: "Pictures/God_of_War_Ragnarok.jpg",
        description: "A thrilling action-packed story game!",
        alt: "Description of God of War Ragnorok",
        priceCents: 6999,
        stock: 10, // Edit the starting inventory here.
        category: "games",
    },
    {
        name: "Horizon Zero Dawn",
        image: "Pictures/Horizon_Zero_Dawn.jpg",
        description: "A post world story game filled with action!",
        alt: "Description of Horizon Zero Dawn",
        priceCents: 6999,
        stock: 10, // Edit the starting inventory here.
        category: "games",
    },
    {
        name: "PS5",
        image: "Pictures/PS5.jfif",
        description: "Playstation 5!",
        alt: "Description of the PS5",
        priceCents: 49999,
        stock: 10, // Edit the starting inventory here.
        category: "consoles",
    },
    {
        name: "Xbox Series X",
        image: "Pictures/Xbox Series X.png",
        description: "Xbox Series X!",
        alt: "Description of Xbox Series X",
        priceCents: 44999,
        stock: 10, // Edit the starting inventory here.
        category: "consoles",
    },
    {
        name: "Nintendo Switch 2",
        image: "Pictures/Nintendo-Switch-2.jfif",
        description: "Nintendo Switch 2!",
        alt: "Description of Nintendo Switch 2",
        priceCents: 44999,
        stock: 10, // Edit the starting inventory here.
        category: "consoles",
    },
    {
        name: "HyperX Cloud 2",
        image: "Pictures/hyperx_cloud_ii_headset.webp",
        description: "HyperX Cloud 2 Headset!",
        alt: "Description of Hyper X Cloud 2",
        priceCents: 7999,
        stock: 10, // Edit the starting inventory here.
        category: "equipment",
    },
    {
        name: "HyperX Keyboard",
        image: "Pictures/hyperx_keyboard.webp",
        description: "HyperX Alloy Origins Core Keyboard!",
        alt: "Description of Hyper X Keyboard",
        priceCents: 8999,
        stock: 10, // Edit the starting inventory here.
        category: "equipment",
    },
    {
        name: "Logitech G502 Hero Mouse",
        image: "Pictures/G502_Hero_Mouse.jfif",
        description: "Logitech G502 Hero Mouse!",
        alt: "Description of Logitech G502 Hero Mouse",
        priceCents: 4999,
        stock: 10, // Edit the starting inventory here.
        category: "equipment",
    },
    {
        name: "Kratos Funko Pop",
        image: "Pictures/Kratos Funko Pop.png",
        description: "Kratos Funko Pop!",
        alt: "Description of Kratos Funko Pop",
        priceCents: 1499,
        stock: 10, // Edit the starting inventory here.
        category: "figurines",
    },
    {
        name: "Naruto Funko Pop",
        image: "Pictures/Naruto Funko Pop.png",
        description: "Naruto Funko Pop!",
        alt: "Description of Naruto Funko Pop",
        priceCents: 1499,
        stock: 10, // Edit the starting inventory here.
        category: "figurines",
    },
    {
        name: "Batman Funko Pop",
        image: "Pictures/Batman Funko Pop.png",
        description: "Batman Funko Pop!",
        alt: "Description of Batman Funko Pop",
        priceCents: 1499,
        stock: 10, // Edit the starting inventory here.
        category: "figurines",
    }
];

const CART_KEY = "gamer-store-v2";
const formatPrice = cents => `$${(cents / 100).toFixed(2)}`;
const emptyState = () => ({ cart: {}, sold: {}, lastOrder: null });

function loadState() {
    try {
        const raw = JSON.parse(localStorage.getItem(CART_KEY) || "null");
        const next = emptyState();
        if (raw) {
            for (let i = 0; i < products.length; i++) {
                const sold = Number(raw.sold?.[i] || 0);
                next.sold[i] = Number.isInteger(sold) ? Math.max(0, Math.min(products[i].stock, sold)) : 0;
                const qty = Number(raw.cart?.[i] || 0);
                if (Number.isInteger(qty) && qty > 0) {
                    const allowed = Math.min(qty, products[i].stock - next.sold[i]);
                    if (allowed > 0) next.cart[i] = allowed;
                }
            }
            next.lastOrder = raw.lastOrder || null;
        } else {
            // Preserve items from the previous version of this project.
            const legacy = JSON.parse(localStorage.getItem("gamer-cart-v1") || "[]");
            if (Array.isArray(legacy)) for (const i of legacy) {
                if (Number.isInteger(i) && products[i]) next.cart[i] = Math.min(products[i].stock, (next.cart[i] || 0) + 1);
            }
        }
        return next;
    } catch { return emptyState(); }
}
let storeState = loadState();

function readCart() {
    return Object.entries(storeState.cart).flatMap(([i, qty]) => Array(qty).fill(Number(i)));
}
function availableStock(index) {
    return products[index].stock - (storeState.sold[index] || 0) - (storeState.cart[index] || 0);
}
function cartSubtotal() {
    return readCart().reduce((sum, i) => sum + products[i].priceCents, 0);
}
function saveState(next) {
    try { localStorage.setItem(CART_KEY, JSON.stringify(next)); }
    catch {
        showCartMessage("Unable to save the cart. Allow browser storage and use Live Server.");
        return false;
    }
    storeState = next;
    renderCart();
    updateStock();
    document.dispatchEvent(new Event("cart-changed"));
    return true;
}
function setQuantity(index, quantity) {
    if (!products[index] || !Number.isInteger(quantity) || quantity < 0) {
        showCartMessage("Enter a whole-number quantity of at least 1, or use Remove.");
        renderCart();
        return false;
    }
    const limit = products[index].stock - (storeState.sold[index] || 0);
    if (quantity > limit) {
        showCartMessage(`Only ${limit} ${products[index].name} available.`);
        renderCart();
        return false;
    }
    const next = structuredClone(storeState);
    if (quantity) next.cart[index] = quantity;
    else delete next.cart[index];
    return saveState(next);
}
function addToCart(index) {
    if (availableStock(index) <= 0) return false;
    const saved = setQuantity(index, (storeState.cart[index] || 0) + 1);
    if (saved) showCartMessage(`${products[index].name} added to your cart.`);
    return saved;
}
function clearCart() {
    const next = structuredClone(storeState);
    next.cart = {};
    if (saveState(next)) showCartMessage("Cart cleared. Items returned to available stock.");
}
function completeOrder(discount, coupon) {
    if (!readCart().length) return null;
    const next = structuredClone(storeState);
    const subtotal = cartSubtotal();
    const order = {
        id: `ORDER-${Date.now()}`,
        date: new Date().toISOString(),
        items: Object.entries(next.cart).map(([i, quantity]) => ({
            name: products[i].name, quantity, priceCents: products[i].priceCents
        })),
        subtotal, discount, total: subtotal - discount, coupon
    };
    for (const [i, qty] of Object.entries(next.cart)) next.sold[i] = (next.sold[i] || 0) + qty;
    next.cart = {};
    next.lastOrder = order;
    return saveState(next) ? order : null;
}
function showCartMessage(message) {
    const status = document.querySelector("#cart-feedback");
    if (status) status.textContent = message;
}
function renderCart() {
    const list = document.querySelector("#cart-items");
    if (!list) return;
    list.replaceChildren();
    if (!readCart().length) {
        const item = document.createElement("li");
        item.textContent = "Your cart is empty.";
        list.append(item);
    }
    for (const [key, qty] of Object.entries(storeState.cart)) {
        const index = Number(key), product = products[index];
        const item = document.createElement("li");
        const text = document.createElement("p");
        text.textContent = `${product.name} — ${formatPrice(product.priceCents)} each — ${formatPrice(product.priceCents * qty)}`;
        const label = document.createElement("label");
        label.textContent = "Quantity ";
        const input = document.createElement("input");
        input.type = "number"; input.min = "1"; input.step = "1";
        input.max = String(product.stock - (storeState.sold[index] || 0));
        input.value = String(qty);
        input.setAttribute("aria-label", `Quantity for ${product.name}`);
        input.addEventListener("change", () => setQuantity(index, Number(input.value)));
        const remove = document.createElement("button");
        remove.type = "button"; remove.textContent = "Remove";
        remove.setAttribute("aria-label", `Remove ${product.name}`);
        remove.addEventListener("click", () => setQuantity(index, 0));
        label.append(input); item.append(text, label, remove); list.append(item);
    }
    const subtotal = document.querySelector("#subtotal");
    if (subtotal) subtotal.textContent = formatPrice(cartSubtotal());
    const total = document.querySelector("#cart-total");
    if (total) total.textContent = formatPrice(cartSubtotal());
    const clear = document.querySelector("#clear-cart");
    if (clear) clear.disabled = !readCart().length;
    const checkout = document.querySelector("#go-checkout");
    if (checkout) checkout.disabled = !readCart().length;
}
function updateStock() {
    document.querySelectorAll("[data-stock-index]").forEach(node => {
        const index = Number(node.dataset.stockIndex);
        node.textContent = `Available stock: ${availableStock(index)}`;
    });
    document.querySelectorAll("[data-add-index]").forEach(button => {
        const out = availableStock(Number(button.dataset.addIndex)) === 0;
        button.disabled = out;
        button.textContent = out ? "Out of Stock" : "Add to cart";
        button.title = out ? "Out of Stock" : "Add to cart";
        button.parentElement.title = button.title;
    });
}
const productGrid = document.querySelector("#products");
if (productGrid) {
    const category = productGrid.dataset.category || "all";
    for (const [index, product] of products.entries()) {
        if (category !== "all" && product.category !== category) continue;
        const card = document.createElement("section");
        const title = document.createElement("h3"); title.textContent = product.name;
        const image = document.createElement("img");
        image.src = product.image; image.alt = product.alt; image.width = 300;
        const description = document.createElement("p"); description.textContent = product.description;
        const price = document.createElement("p"); price.textContent = `${formatPrice(product.priceCents)} (demo price)`;
        const stock = document.createElement("p"); stock.dataset.stockIndex = index;
        const button = document.createElement("button");
        button.type = "button"; button.dataset.addIndex = index;
        button.addEventListener("click", () => addToCart(index));
        const wrapper = document.createElement("span"); wrapper.append(button);
        card.append(title, image, description, price, stock, wrapper); productGrid.append(card);
    }
    const cart = document.createElement("section"); cart.className = "shopping-cart";
    cart.innerHTML = `<h2>Shopping Cart</h2>
        <p id="cart-feedback" role="status" aria-live="polite"></p>
        <ul id="cart-items"></ul><p>Total: <strong id="cart-total"></strong></p>
        <button type="button" id="clear-cart">Clear Cart</button>
        <button type="button" id="go-checkout">Go to Checkout</button>`;
    productGrid.after(cart);
    document.querySelector("#go-checkout").addEventListener("click", () => { window.location.href = "checkout.html"; });
}
document.querySelector("#clear-cart")?.addEventListener("click", clearCart);
renderCart(); updateStock();
window.addEventListener("storage", event => {
    if (event.key === CART_KEY || event.key === null) {
        storeState = loadState(); renderCart(); updateStock();
        document.dispatchEvent(new Event("cart-changed"));
    }
});
